const express = require("express");
const {
  getAllUser,
  getUserById,
  hapusUser,
  tambahUser,
} = require("./controller");
const router = express.Router();

router.get("/", getAllUser);
router.get("/cari/:id", getUserById);
router.delete("/hapus/:id", hapusUser);
router.post("/tambah", tambahUser);

module.exports = router;
